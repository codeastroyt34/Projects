<?php
session_start();
session_destroy();
header('location:index.php');
?><!-- Visit codeastro.com for more projects -->